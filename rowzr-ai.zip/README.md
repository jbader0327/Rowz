# 🧠 Rowzr AI v3.1

> Static single-file deployment — works on GitHub Pages, Netlify, or any web server.

## Deploy to rowzr.com

### Option A: GitHub Pages (Recommended)
1. Push these files to a GitHub repo
2. Go to **Settings → Pages**
3. Set Source: **Deploy from a branch → main → / (root)**
4. Click Save
5. Set custom domain: **rowzr.com**
6. Enable **Enforce HTTPS**

### Option B: Netlify
1. Push to GitHub, connect repo in Netlify
2. `netlify.toml` auto-configures everything
3. Add custom domain: rowzr.com

## DNS Setup for rowzr.com
At your domain registrar, add:
- `A` record → `185.199.108.153` (GitHub Pages)
- `A` record → `185.199.109.153`
- `A` record → `185.199.110.153`
- `A` record → `185.199.111.153`
- `CNAME` → `www` → `YOUR_USER.github.io`

## Files
```
index.html    ← The entire app (138KB, self-contained)
CNAME         ← Custom domain for GitHub Pages
404.html      ← SPA redirect
.nojekyll     ← Skip Jekyll processing
netlify.toml  ← Netlify config (if using Netlify)
package.json  ← No-op build safety
```

MIT License · Rowzr AI
